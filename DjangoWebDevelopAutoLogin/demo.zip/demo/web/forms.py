from django import forms
class User_reg(forms.Form):
	username=forms.CharField(label='用户名',max_length=10)
	password=forms.CharField(label='密码',max_length=20,widget=forms.PasswordInput())
	email=forms.EmailField(label='邮箱',error_messages={"required": '邮箱不能为空','invalid': '邮箱格式错误'})
class User_login(forms.Form):
	username=forms.CharField(label='用户名',max_length=10)
	password=forms.CharField(label='密码',max_length=20,widget=forms.PasswordInput())
# class User_wj(forms.Form):
# 	username=forms.CharField(label='用户名',max_length=10)
# 	password=forms.CharField(label='密码',max_length=20,widget=forms.PasswordInput())
# 	email=forms.EmailField(label='邮箱',error_messages={"required": '邮箱不能为空','invalid': '邮箱格式错误'})
