from django.shortcuts import render,reverse,redirect
from .forms import User_reg,User_login
from django.http import HttpResponse,JsonResponse
from web.models import user
import time
from django.db.models import Q
from django.contrib.auth.hashers import make_password,check_password
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import EmailMessage
import string
import random
t=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
r=string.ascii_letters+string.digits
aa=random.sample(r,6)
ab=''.join(aa)
def index(request):
	username=request.session.get('username')
	if username:
		return render(request,'logout.html',{'username':username,'time':t})
	else:
		return render(request,'index.html')
def register(request):
	if request.method=='POST':
		form=User_reg(request.POST)
		if form.is_valid():
			username=form.cleaned_data.get('username')
			password=form.cleaned_data.get('password')
			password=make_password(password)
			email=form.cleaned_data.get('email')
			# obj,use=user.objects.get_or_create(username=username,password=password,email=email)
			if user.objects.filter(Q(username=username) | Q(email=email)).exists():
				return HttpResponse('已注册')
			else:
				use=user.objects.create(username=username,password=password,email=email)
				use.save()
				return render(request,'page.html')
		else:
			return HttpResponse('注册失败')
	else:
		form=User_reg()
		return render(request,'register.html',{'form':form})
def login(request):
	if request.method=='POST':
		form=User_login(request.POST)
		if form.is_valid():
			username=form.cleaned_data.get('username')
			password=form.cleaned_data.get('password')
			check=request.POST.get('check')
			use=user.objects.get(username=username)
			if use:
				if  check_password(password,use.password): #检验密码是否正确
					if check=='记住密码':
						request.session['username']=username #添加到session
						request.session.set_expiry(604800)  #一周后失效
						return render(request,'logout.html',{'username':username,'time':t})
					else:
						return render(request,'logout.html',{'username':username,'time':t})
				else:
					
						return HttpResponse('用户名或者密码错误')			
			else:
				return HttpResponse('用户不存在')
		else:
			return HttpResponse('error')
	else:
		form=User_login()
		return render(request,'login.html',{'form':form})
def logout(request):
	# del request.session['username']
	request.session.flush()
	return redirect('/web/index/')
def lg(request):
	if 'username' not in request.session:
		return render(request,'index.html')
	else:
		return render(request,'logout.html',{'username':request.session.get('username'),'time':t})
def change(request):
	if request.method=='POST':
		form=User_login(request.POST)
		if form.is_valid():
			username=form.cleaned_data.get('username')
			password=form.cleaned_data.get('password')
			password1=request.POST.get('password1')
			use=user.objects.get(username=username)
			if use and password==password1 and use.password!=password1:
				use.password=make_password(password)
				use.save()
				use.refresh_from_db() #刷新数据
				return JsonResponse({'status':'ok','error':'修改成功'})
			else:
				return JsonResponse({'status':'fail','error':'修改失败'})
		else:
			return HttpResponse('表单验证未通过')
	else:
		form=User_login()
		return render(request,'change.html',{'form':form})
@csrf_exempt
def find(request):
	if request.method == "GET":
		return render(request, 'find.html')
	elif request.method == "POST":
		username=request.POST.get('username')
		em=request.POST.get('email')
		yzm=request.POST.get('yzm')
		password=request.POST.get('password')
		e=user.objects.get(username=username)
		if e:	
			result=EmailMessage('django开发者',
			'这是一封帮你找回密码的邮件,你只要输入验证码即可,本次验证码为<h3><b>%s</b></h3>'%ab,
			'2091500484@qq.com',[em])
			result.content_subtype="html"
			result.send()
			if yzm is not None:
				if ab==yzm:
					if check_password(password,e.password):
						return HttpResponse('密码未改变')
					else:
						e.password=make_password(password)
						e.save()
						e.refresh_from_db() 
						return HttpResponse('成功重置密码')
				else:
					return HttpResponse('验证码错误')
			else:
				return HttpResponse('请输入验证码')
		else:
			return HttpResponse('用户不存在')

