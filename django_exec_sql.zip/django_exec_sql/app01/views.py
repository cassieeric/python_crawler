from django.shortcuts import render

from app01 import models
from django.db import connection


def query_all_dict(sql, params=None):
    '''
    查询所有结果返回字典类型数据
    :param sql:
    :param params:
    :return:
    '''
    with connection.cursor() as cursor:
        if params:
            cursor.execute(sql, params=params)
        else:
            cursor.execute(sql)
        col_names = [desc[0] for desc in cursor.description]
        row = cursor.fetchall()
        rowList = []
        for list in row:
            tMap = dict(zip(col_names, list))
            rowList.append(tMap)
        return rowList


def query_one_dict(sql, params=None):
    """
    查询一个结果返回字典类型数据
    :param sql:
    :param params:
    :return:
    """
    with connection.cursor() as cursor:
        if params:
            cursor.execute(sql, params=params)
        else:
            cursor.execute(sql)
        col_names = [desc[0] for desc in cursor.description]
        row = cursor.fetchone()
        tMap = dict(zip(col_names, row))
        return tMap


# Create your views here.
def book_list(request):
    # 执行原生sql并且封装成字典
    # data = query_one_dict("select * from app01_book where id=%s",[1,])
    # print(data)

    # 真正的原生sql
    # cursor = connection.cursor()
    # print(type(cursor))
    # cursor.execute("select * from app01_book where id=%s", [1, ])
    # raw = cursor.fetchall()
    # print(raw)

    # raw,返回的仍然是Book模型对象
    # book_list = models.Book.objects.raw("select * from app01_book where id=%s",
    #                                     [1, ])  # <RawQuerySet: select * from app01_book>
    # for book in book_list:
    #     print(book.title, book.author)

    # book_list = models.Book.objects.filter(publisher_date__month=9,title="帅哥养成记")
    # print(book_list.query)
    # 使用extra

    # 执行原生sql并且封装成字典
    # data = query_one_dict("select * from app01_book")
    # print(data)
    return render(request, "booklist.html", )
