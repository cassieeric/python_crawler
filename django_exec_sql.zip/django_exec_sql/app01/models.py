from django.db import models


# Create your models here.
class Book(models.Model):
    title = models.CharField(verbose_name="书名", max_length=32)
    describe = models.TextField(verbose_name="描述")
    author = models.CharField(verbose_name="作者", max_length=32)
    publisher = models.CharField(verbose_name="出版社", max_length=32)
    publisher_date = models.DateField(verbose_name="publisher")
