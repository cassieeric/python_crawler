from django.contrib import admin
from app01 import models
import time


class BookAdmin(admin.ModelAdmin):
    def format_publisher_date(self):
        # print(self.publisher_date.strftime("%Y-%m-%d"), type(self.publisher_date))
        return self.publisher_date.strftime("%Y-%m-%d")

    format_publisher_date.short_description = "时间"
    list_display = ["title", "describe", "author", "publisher", format_publisher_date]


# Register your models here.
admin.site.register(models.Book, BookAdmin)
