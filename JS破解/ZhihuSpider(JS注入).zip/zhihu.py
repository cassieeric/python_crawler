import hashlib,requests,json,re,execjs
import time
from urllib import parse
import pymysql
from MyTools.CommonMethodTool import get_proxy
# 打开数据库连接 参数依次如下：
conn = pymysql.connect(host='localhost',user='root',password='123456',database='vmscrawl',port=3306)
# 使用cursor()方法获取操作游标
cursor = conn.cursor()

# 处理加密问题
def get_encrypt(url,page=None,keyword=None):
    zhihu_js = '''
    const jsdom = require("jsdom");
    const { JSDOM } = jsdom;
    const dom = new JSDOM(`<!DOCTYPE html><p>Hello world</p>`);
    window = dom.window;
    document = window.document;
    XMLHttpRequest = window.XMLHttpRequest;

    	var exports = {}
    	function t(e) {
            return (t = "function" == typeof Symbol && "symbol" == typeof Symbol.A ? function(e) {
                return typeof e;
            }
            : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            }
            )(e)
        }
        Object.defineProperty(exports, "__esModule", {
            value: !0
        });
        var A = "2.0"
          , __g = {};
        function s() {}
        function i(e) {
            this.t = (2048 & e) >> 11,
            this.s = (1536 & e) >> 9,
            this.i = 511 & e,
            this.h = 511 & e
        }
        function h(e) {
            this.s = (3072 & e) >> 10,
            this.h = 1023 & e
        }
        function a(e) {
            this.a = (3072 & e) >> 10,
            this.c = (768 & e) >> 8,
            this.n = (192 & e) >> 6,
            this.t = 63 & e
        }
        function c(e) {
            this.s = e >> 10 & 3,
            this.i = 1023 & e
        }
        function n() {}
        function e(e) {
            this.a = (3072 & e) >> 10,
            this.c = (768 & e) >> 8,
            this.n = (192 & e) >> 6,
            this.t = 63 & e
        }
        function o(e) {
            this.h = (4095 & e) >> 2,
            this.t = 3 & e
        }
        function r(e) {
            this.s = e >> 10 & 3,
            this.i = e >> 2 & 255,
            this.t = 3 & e
        }
        s.prototype.e = function(e) {
            e.o = !1
        }
        ,
        i.prototype.e = function(e) {
            switch (this.t) {
            case 0:
                e.r[this.s] = this.i;
                break;
            case 1:
                e.r[this.s] = e.k[this.h]
            }
        }
        ,
        h.prototype.e = function(e) {
            e.k[this.h] = e.r[this.s]
        }
        ,
        a.prototype.e = function(e) {
            switch (this.t) {
            case 0:
                e.r[this.a] = e.r[this.c] + e.r[this.n];
                break;
            case 1:
                e.r[this.a] = e.r[this.c] - e.r[this.n];
                break;
            case 2:
                e.r[this.a] = e.r[this.c] * e.r[this.n];
                break;
            case 3:
                e.r[this.a] = e.r[this.c] / e.r[this.n];
                break;
            case 4:
                e.r[this.a] = e.r[this.c] % e.r[this.n];
                break;
            case 5:
                e.r[this.a] = e.r[this.c] == e.r[this.n];
                break;
            case 6:
                e.r[this.a] = e.r[this.c] >= e.r[this.n];
                break;
            case 7:
                e.r[this.a] = e.r[this.c] || e.r[this.n];
                break;
            case 8:
                e.r[this.a] = e.r[this.c] && e.r[this.n];
                break;
            case 9:
                e.r[this.a] = e.r[this.c] !== e.r[this.n];
                break;
            case 10:
                e.r[this.a] = t(e.r[this.c]);
                break;
            case 11:
                e.r[this.a] = e.r[this.c]in e.r[this.n];
                break;
            case 12:
                e.r[this.a] = e.r[this.c] > e.r[this.n];
                break;
            case 13:
                e.r[this.a] = -e.r[this.c];
                break;
            case 14:
                e.r[this.a] = e.r[this.c] < e.r[this.n];
                break;
            case 15:
                e.r[this.a] = e.r[this.c] & e.r[this.n];
                break;
            case 16:
                e.r[this.a] = e.r[this.c] ^ e.r[this.n];
                break;
            case 17:
                e.r[this.a] = e.r[this.c] << e.r[this.n];
                break;
            case 18:
                e.r[this.a] = e.r[this.c] >>> e.r[this.n];
                break;
            case 19:
                e.r[this.a] = e.r[this.c] | e.r[this.n];
                break;
            case 20:
                e.r[this.a] = !e.r[this.c]
            }
        }
        ,
        c.prototype.e = function(e) {
            e.Q.push(e.C),
            e.B.push(e.k),
            e.C = e.r[this.s],
            e.k = [];
            for (var t = 0; t < this.i; t++)
                e.k.unshift(e.f.pop());
            e.g.push(e.f),
            e.f = []
        }
        ,
        n.prototype.e = function(e) {
            e.C = e.Q.pop(),
            e.k = e.B.pop(),
            e.f = e.g.pop()
        }
        ,
        e.prototype.e = function(e) {
            switch (this.t) {
            case 0:
                e.u = e.r[this.a] >= e.r[this.c];
                break;
            case 1:
                e.u = e.r[this.a] <= e.r[this.c];
                break;
            case 2:
                e.u = e.r[this.a] > e.r[this.c];
                break;
            case 3:
                e.u = e.r[this.a] < e.r[this.c];
                break;
            case 4:
                e.u = e.r[this.a] == e.r[this.c];
                break;
            case 5:
                e.u = e.r[this.a] != e.r[this.c];
                break;
            case 6:
                e.u = e.r[this.a];
                break;
            case 7:
                e.u = !e.r[this.a]
            }
        }
        ,
        o.prototype.e = function(e) {
            switch (this.t) {
            case 0:
                e.C = this.h;
                break;
            case 1:
                e.u && (e.C = this.h);
                break;
            case 2:
                e.u || (e.C = this.h);
                break;
            case 3:
                e.C = this.h,
                e.w = null
            }
            e.u = !1
        }
        ,
        r.prototype.e = function(e) {
            switch (this.t) {
            case 0:
                for (var t = [], n = 0; n < this.i; n++)
                    t.unshift(e.f.pop());
                e.r[3] = e.r[this.s](t[0], t[1]);
                break;
            case 1:
                for (var r = e.f.pop(), o = [], i = 0; i < this.i; i++)
                    o.unshift(e.f.pop());
                e.r[3] = e.r[this.s][r](o[0], o[1]);
                break;
            case 2:
                for (var a = [], c = 0; c < this.i; c++)
                    a.unshift(e.f.pop());
                e.r[3] = new e.r[this.s](a[0],a[1])
            }
        }
        ;
        var k = function(e) {
            for (var t = 66, n = [], r = 0; r < e.length; r++) {
                var o = 24 ^ e.charCodeAt(r) ^ t;
                n.push(String.fromCharCode(o)),
                t = o
            }
            return n.join("")
        };
        function Q(e) {
            this.t = (4095 & e) >> 10,
            this.s = (1023 & e) >> 8,
            this.i = 1023 & e,
            this.h = 63 & e
        }
        function C(e) {
            this.t = (4095 & e) >> 10,
            this.a = (1023 & e) >> 8,
            this.c = (255 & e) >> 6
        }
        function B(e) {
            this.s = (3072 & e) >> 10,
            this.h = 1023 & e
        }
        function f(e) {
            this.h = 4095 & e
        }
        function g(e) {
            this.s = (3072 & e) >> 10
        }
        function u(e) {
            this.h = 4095 & e
        }
        function w(e) {
            this.t = (3840 & e) >> 8,
            this.s = (192 & e) >> 6,
            this.i = 63 & e
        }
        function G() {
            this.r = [0, 0, 0, 0],
            this.C = 0,
            this.Q = [],
            this.k = [],
            this.B = [],
            this.f = [],
            this.g = [],
            this.u = !1,
            this.G = [],
            this.b = [],
            this.o = !1,
            this.w = null,
            this.U = null,
            this.F = [],
            this.R = 0,
            this.J = {
                0: s,
                1: i,
                2: h,
                3: a,
                4: c,
                5: n,
                6: e,
                7: o,
                8: r,
                9: Q,
                10: C,
                11: B,
                12: f,
                13: g,
                14: u,
                15: w
            }
        }
        Q.prototype.e = function(e) {
            switch (this.t) {
            case 0:
                e.f.push(e.r[this.s]);
                break;
            case 1:
                e.f.push(this.i);
                break;
            case 2:
                e.f.push(e.k[this.h]);
                break;
            case 3:
                e.f.push(k(e.b[this.h]))
            }
        }
        ,
        C.prototype.e = function(A) {
            switch (this.t) {
            case 0:
                var t = A.f.pop();
                A.r[this.a] = A.r[this.c][t];
                break;
            case 1:
                var s = A.f.pop()
                  , i = A.f.pop();
                A.r[this.c][s] = i;
                break;
            case 2:
                var h = A.f.pop();
                A.r[this.a] = eval(h)
            }
        }
        ,
        B.prototype.e = function(e) {
            e.r[this.s] = k(e.b[this.h])
        }
        ,
        f.prototype.e = function(e) {
            e.w = this.h
        }
        ,
        g.prototype.e = function(e) {
            throw e.r[this.s]
        }
        ,
        u.prototype.e = function(e) {
            var t = this
              , n = [0];
            e.k.forEach(function(e) {
                n.push(e)
            });
            var r = function(r) {
                var o = new G;
                return o.k = n,
                o.k[0] = r,
                o.v(e.G, t.h, e.b, e.F),
                o.r[3]
            };
            r.toString = function() {
                return "() { [native code] }"
            }
            ,
            e.r[3] = r
        }
        ,
        w.prototype.e = function(e) {
            switch (this.t) {
            case 0:
                for (var t = {}, n = 0; n < this.i; n++) {
                    var r = e.f.pop();
                    t[e.f.pop()] = r
                }
                e.r[this.s] = t;
                break;
            case 1:
                for (var o = [], i = 0; i < this.i; i++)
                    o.unshift(e.f.pop());
                e.r[this.s] = o
            }
        }
        ,
        G.prototype.D = function(e) {
            console.log(window.atob(e));
            for (var t = window.atob(e), n = t.charCodeAt(0) << 8 | t.charCodeAt(1), r = [], o = 2; o < n + 2; o += 2)
                r.push(t.charCodeAt(o) << 8 | t.charCodeAt(o + 1));
            this.G = r;
            for (var i = [], a = n + 2; a < t.length; ) {
                var c = t.charCodeAt(a) << 8 | t.charCodeAt(a + 1)
                  , s = t.slice(a + 2, a + 2 + c);
                i.push(s),
                a += c + 2
            }
            this.b = i
        }
        ,
        G.prototype.v = function(e, t, n) {
            for (t = t || 0,
            n = n || [],
            this.C = t,
            "string" == typeof e ? this.D(e) : (this.G = e,
            this.b = n),
            this.o = !0,
            this.R = Date.now(); this.o; ) {
                var r = this.G[this.C++];
                if ("number" != typeof r)
                    break;
                var o = Date.now();
                if (500 < o - this.R)
                    return;
                this.R = o;
                try {
                    this.e(r)
                } catch (e) {
                    this.U = e,
                    this.w && (this.C = this.w)
                }
            }
        }
        ,
        G.prototype.e = function(e) {
            var t = (61440 & e) >> 12;
            new this.J[t](e).e(this)
        }
             ,
         "undefined" != typeof window && (new G).v("AxjgB5MAnACoAJwBpAAAABAAIAKcAqgAMAq0AzRJZAZwUpwCqACQACACGAKcBKAAIAOcBagAIAQYAjAUGgKcBqFAuAc5hTSHZAZwqrAIGgA0QJEAJAAYAzAUGgOcCaFANRQ0R2QGcOKwChoANECRACQAsAuQABgDnAmgAJwMgAGcDYwFEAAzBmAGcSqwDhoANECRACQAGAKcD6AAGgKcEKFANEcYApwRoAAxB2AGcXKwEhoANECRACQAGAKcE6AAGgKcFKFANEdkBnGqsBUaADRAkQAkABgCnBagAGAGcdKwFxoANECRACQAGAKcGKAAYAZx+rAZGgA0QJEAJAAYA5waoABgBnIisBsaADRAkQAkABgCnBygABoCnB2hQDRHZAZyWrAeGgA0QJEAJAAYBJwfoAAwFGAGcoawIBoANECRACQAGAOQALAJkAAYBJwfgAlsBnK+sCEaADRAkQAkABgDkACwGpAAGAScH4AJbAZy9rAiGgA0QJEAJACwI5AAGAScH6AAkACcJKgAnCWgAJwmoACcJ4AFnA2MBRAAMw5gBnNasCgaADRAkQAkABgBEio0R5EAJAGwKSAFGACcKqAAEgM0RCQGGAYSATRFZAZzshgAtCs0QCQAGAYSAjRFZAZz1hgAtCw0QCQAEAAgB7AtIAgYAJwqoAASATRBJAkYCRIANEZkBnYqEAgaBxQBOYAoBxQEOYQ0giQKGAmQABgAnC6ABRgBGgo0UhD/MQ8zECALEAgaBxQBOYAoBxQEOYQ0gpEAJAoYARoKNFIQ/zEPkAAgChgLGgkUATmBkgAaAJwuhAUaCjdQFAg5kTSTJAsQCBoHFAE5gCgHFAQ5hDSCkQAkChgBGgo0UhD/MQ+QACAKGAsaCRQCOYGSABoAnC6EBRoKN1AUEDmRNJMkCxgFGgsUPzmPkgAaCJwvhAU0wCQFGAUaCxQGOZISPzZPkQAaCJwvhAU0wCQFGAUaCxQMOZISPzZPkQAaCJwvhAU0wCQFGAUaCxQSOZISPzZPkQAaCJwvhAU0wCQFGAkSAzRBJAlz/B4FUAAAAwUYIAAIBSITFQkTERwABi0GHxITAAAJLwMSGRsXHxMZAAk0Fw8HFh4NAwUABhU1EBceDwAENBcUEAAGNBkTGRcBAAFKAAkvHg4PKz4aEwIAAUsACDIVHB0QEQ4YAAsuAzs7AAoPKToKDgAHMx8SGQUvMQABSAALORoVGCQgERcCAxoACAU3ABEXAgMaAAsFGDcAERcCAxoUCgABSQAGOA8LGBsPAAYYLwsYGw8AAU4ABD8QHAUAAU8ABSkbCQ4BAAFMAAktCh8eDgMHCw8AAU0ADT4TGjQsGQMaFA0FHhkAFz4TGjQsGQMaFA0FHhk1NBkCHgUbGBEPAAFCABg9GgkjIAEmOgUHDQ8eFSU5DggJAwEcAwUAAUMAAUAAAUEADQEtFw0FBwtdWxQTGSAACBwrAxUPBR4ZAAkqGgUDAwMVEQ0ACC4DJD8eAx8RAAQ5GhUYAAFGAAAABjYRExELBAACWhgAAVoAQAg/PTw0NxcQPCQ5C3JZEBs9fkcnDRcUAXZia0Q4EhQgXHojMBY3MWVCNT0uDhMXcGQ7AUFPHigkQUwQFkhaAkEACjkTEQspNBMZPC0ABjkTEQsrLQ==");
         var b = function(e) {
            return __g._encrypt(encodeURIComponent(e))
         };
         exports.ENCRYPT_VERSION = A,
         exports.default = b

         function b(e) {
            console.log(e);
            console.log(encodeURIComponent(e));
            return __g._encrypt(encodeURIComponent(e))
       };
    '''
    if 'https:' in url:
        search_hash_id = re.findall('search_hash_id=(.*?)&', url)[0]
        x_81 = '3_2.0aR_sn77yn6O92wOB8hPZnQr0EMYxc4f18wNBUgpT2Htue8FqK6P0EQ9y-LS9-hp1DufI-we8gGHPgJO1xuPZ0GxCTJHR7820XM20cLRGDJXfgGCBxupMuD_Ie8FL7AtqM6O1VDQyQ6nxrRPCHukMoCXBEgOsiRP0XL2ZUBXmDDV9qhnyTXFMnXcTF_ntRueThHo__qHLAgwxWve8YcLGk4xm69SfiwxO6DOmtcCM27C9XhOG8eLKNJuOc7YPvHCO_G310brmSTOGNCV1hGpYLvpfUUgKPqN_jCLYrcwfeMFYP9L_2Bcfo6HmprL_-hVCf9SCOuH1UwxOfGVfm_xqYrVYc_NmDwpyiBxYqg9Bku21HJxm5qfz60OKeMtOc7OGTgFOk0CBrTpLOhLZnvHfwheYygcObheB8BO9acHOLCpOFBVB8rx1sv3KnvXmicNqMXpOCqp0OGSLCBXGyhe1bgw9UhVOkHwLuhHC6QNC'
        parse_url = f"/api/v4/search_v3?t=general&q{keyword}&correction=1&offset={page*20}&limit=20&filter_fields=&lc_idx={page*20}&show_all_topics=0&search_hash_id={search_hash_id}&search_source=Normal&vertical_info=0%2C0%2C0%2C0%2C0%2C0%2C0%2C0%2C0%2C1"
        request_url = 'https://www.zhihu.com'+parse_url
        with open('zhihucookie.txt', 'r', encoding='utf-8') as c:
            cookie = c.read()
        star = 'd_c0='
        end = ';'
        cookie_mes = cookie[cookie.index(star):].replace(star, '')
        cookie_mes = cookie_mes[:cookie_mes.index(end)]
        f = "+".join(["101_3_2.0", parse_url, cookie_mes,x_81])
        fmd5 = hashlib.new('md5', f.encode()).hexdigest()
        ctx1 = execjs.compile(zhihu_js, cwd='node_modules')
        encrypt_str = "2.0_%s" % ctx1.call('b', fmd5)
        headers = {
            'authority': 'www.zhihu.com',
            'x-zse-93': '101_3_2.0',
            'x-ab-param': 'tp_contents=1;qap_question_visitor= 0;top_test_4_liguangyi=1;pf_adjust=1;zr_expslotpaid=1;pf_noti_entry_num=2;qap_question_author=0;se_ffzx_jushen1=0;zr_slotpaidexp=1;tp_zrec=1;tp_dingyue_video=0;tp_topic_style=0',
            'x-ab-pb': 'CtoBtQvMArcDMwTcBrkCjATcC7QKWwbkCuALMwXnBSoGTwMcBokMPwZWDM8LUgt9AvQDDgXoBqsG8wMZBcYGoQOmBjsCKQUYBjEGXAYnB6ADNwUWBrQAVwRSBU8HCwRVBbIFUweNBIAFQAZ8Bj8Amwt0AZ4F1wsBC2kBUQWiBvQLQwAPC8IFNAxqAekEiwUqA+wKNwyEAtgCMAasBhsA4ATjBaIDEQUVBfgDCgT6BkEGlAYHB0UEMgUHDDID1gR+BqYEAQZHAEAB9gJgC1YFQgTRBtcCjAXrBlAD2gQSbQMAAAAAFQQAAAAAAAAAAAAAAAEBCwEBAAAAAAAAAAAAAgAAAQAAAAAAAAEAAAAAFAAEABgBAAAAAQACAAEAABUBAgABAAABAQEAAAAAAAIAAAACAQECAAALAAABAAAAAAAAAQAAAAMBAAAAAAE=',
            'x-api-version': '3.0.91',
            'x-zst-81': x_81,
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.93 Safari/537.36',
            'sec-ch-ua-mobile': '?0',
            'x-requested-with': 'fetch',
            'x-zse-96': encrypt_str,
            'x-app-za': 'OS=Web',
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="96", "Google Chrome";v="96"',
            'sec-ch-ua-platform': '"Windows"',
            'accept': '*/*',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-dest': 'empty',
            'referer': 'https://www.zhihu.com/search?type=content&q=%E6%B5%B7%E6%B4%8B',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cookie': '_zap=e672191e-00e2-4989-b790-7cae678ca137; _xsrf=20041567-d0cf-41d6-8dfc-3dcf7e38b723; d_c0="AHBQteodLhSPTn8r_unNZHj3uwaRCtW5AYQ=|1639472233"; __snaker__id=mqoUy0CyYU3Jkfvy; gdxidpyhxdE=mEmkYM8%5C3E0TufRjE%5C%2Bfus12zPQIU45VmPDT54fKdtAnQgXG6HEn9oRCQpRQlM%2BQWE%2BYEaPS85QkIIQN5cUytK3Kq4j96%2F18f5mSZII5EaBkRAx7c1S1PkPH%2ByYM2Govf%5CS%5CbBilIN%5CbHx7%5CiUrVDijkJArl%2B5%2F7rG4HAGn4Le6off%2Bb%3A1639473517368; _9755xjdesxxd_=32; YD00517437729195%3AWM_NI=opBWbLzd6T62zlsipbWyzcMpKF0R71oPPlaWwBehshPM8MWgF69nTfEsa08KRYq1Y%2BlDP%2BzqnJPs70TyMQWtuCXr5D4N0B0We0wkFNhY4GvTigXTo%2BYzrcTjUJnhJrZPQWE%3D; YD00517437729195%3AWM_NIKE=9ca17ae2e6ffcda170e2e6eea4e26a8aebe1a9aa6be9a88ab7c45b979b8eabf180b4f19aa9e166aba696ccc12af0fea7c3b92aadb08eb8e148babcfab5b53abab4bd8af36a95a7b684d07c899a00b3b63bad90a08de45db59eab89f2649493f8aed66d86eaf78fd76e87adafd1bb419287bfd2dc21b09ca0ccf97bae96a094b63c98a783b2d680b79d9893b850f89200a3b35da7f0b98cc546ac87fca8f560abb998b5ee219ba6be84d7629796a289c97a9a909fb8c837e2a3; YD00517437729195%3AWM_TID=sZ19tdhwJ%2FRFURFBUUJ64t6UHeniycvE; captcha_ticket_v2="2|1:0|10:1639472627|17:captcha_ticket_v2|704:eyJ2YWxpZGF0ZSI6IkNOMzFfT2lGbFp3LUk2QmlDUFl6aGlqVkl2S1h4NklQZGY0SC51TW40Zllocnc2azZUMlVLeG9IaWFVVDE3Zzc5R2plTTBFLkcyanNkLTFxWktldTFfcHdQMS1oaXB2V0ZqemdrT2k5OEFZc2pROGMtYmoyME5ldFN3b2JZMm1TQ3NyOWNqNDdNSXl3U0xhTS5Iak9aRDRqR1VaMFE0eWRROS5vYWphUWZrRFg0ZVB1VnQ5UFNtRk1Dc1VWMnRyZGpMQmhGMnRPdC5JSU5hQml6LmdRLUpjd3AyNTduVDF1T1l3dVlmSDJUay5sTC1DV0JSZ0gyZl9jMnVyRHhXenlXdG5oblZGZXU3X09scmI0WTJpd1AwSzlxc2t6NXZFLkw0eGRtRGkwR2E3QUN0YVZLREUteVowSy1xc3FOdHc4dDFqQXFna2cxQU5oRUdaamFUeWdKWHVIRDk3U1BXTi1WLlIwSXF3NE1mVi5nbkhNZmloLk5EOVktTHpNdXdnWk00RnlPVlJ3YXBEekgub2pBZ3RRS0tFaWMxN01lTTlwWW1rdVg2YWYyQlk0RlhoX1RteGhRSVNYWnFRanV3cFJuaVF2SmV1cjR2ZTl6TWJyYzJTamtLaC1oSUJrdTd2WWREdUhBRExHbW5zVnoyaF9samJCb0R0RnBjS1FHallqMyJ9|05624d791b1e45e2b53bbed64770795b55e4ccd0b75ae0f2130aa0ffaf307965"; z_c0="2|1:0|10:1639472639|4:z_c0|92:Mi4xY19LZEhnQUFBQUFBY0ZDMTZoMHVGQ1lBQUFCZ0FsVk5fNnVsWWdDRW4yM2U0R0pvSEhTU00xbWJTNmVMSkV4LXd3|5dd41844a5967b078e78c86fe436cfc11e9835e5da0a06320ed51e348b86ee59"; captcha_session_v2="2|1:0|10:1639472640|18:captcha_session_v2|88:emlQa2VlQXRpalZjNm4zMHRnWlNBVE43djM3Vmd3QTdlRitMYmlDeFpHQ0J5WDhBUDhCVnV6MmRBeVphdXVXSQ==|5e7d1286842edeb94c784de7e2d0a75a04c0f9144be538a2f763a4b3010731c5"; tst=r; SESSIONID=rsiSSVnO7Mzpqy6dt1Loms9CGPrUQRntasLJkxa8mlb; JOID=UFodB0vc38LbBsihDdpNVy0d0I0TrqanjFeexU7pkrKnc7OXYwDFdrwEwqcFPhQBOXeFUjL0cymc_bqp4rvwyYc=; osd=UlkdA0re3MLfB8qiDd5MVS4d1IwRraajjVWdxUrokLGnd7KVYADBd74HwqMEPBcBPXaHUTLwciuf_b6o4LjwzYY=; Hm_lvt_98beee57fd2ef70ccdd5ca52b9740c49=1639535923,1639539154,1639718102,1639721911; Hm_lpvt_98beee57fd2ef70ccdd5ca52b9740c49=1639723986; KLBRSID=d017ffedd50a8c265f0e648afe355952|1639725723|1639718100',
        }
        return encrypt_str,request_url,headers
    else:
        request_url = 'https://www.zhihu.com'+url
        parse_url = url
        with open('zhihucookie.txt', 'r', encoding='utf-8') as c:
            cookie = c.read()
        star = 'd_c0='
        end = ';'
        cookie_mes = cookie[cookie.index(star):].replace(star, '')
        cookie_mes = cookie_mes[:cookie_mes.index(end)]
        f = "+".join(["101_3_2.0", parse_url, cookie_mes])
        fmd5 = hashlib.new('md5', f.encode()).hexdigest()
        ctx1 = execjs.compile(zhihu_js, cwd='node_modules')
        encrypt_str = "2.0_%s" % ctx1.call('b', fmd5)
        headers = {
            'authority': 'www.zhihu.com',
            'x-zse-93': '101_3_2.0',
            'x-ab-param': 'tp_contents=1;qap_question_visitor= 0;top_test_4_liguangyi=1;pf_adjust=1;zr_expslotpaid=1;pf_noti_entry_num=2;qap_question_author=0;se_ffzx_jushen1=0;zr_slotpaidexp=1;tp_zrec=1;tp_dingyue_video=0;tp_topic_style=0',
            'x-ab-pb': 'CtoBtQvMArcDMwTcBrkCjATcC7QKWwbkCuALMwXnBSoGTwMcBokMPwZWDM8LUgt9AvQDDgXoBqsG8wMZBcYGoQOmBjsCKQUYBjEGXAYnB6ADNwUWBrQAVwRSBU8HCwRVBbIFUweNBIAFQAZ8Bj8Amwt0AZ4F1wsBC2kBUQWiBvQLQwAPC8IFNAxqAekEiwUqA+wKNwyEAtgCMAasBhsA4ATjBaIDEQUVBfgDCgT6BkEGlAYHB0UEMgUHDDID1gR+BqYEAQZHAEAB9gJgC1YFQgTRBtcCjAXrBlAD2gQSbQMAAAAAFQQAAAAAAAAAAAAAAAEBCwEBAAAAAAAAAAAAAgAAAQAAAAAAAAEAAAAAFAAEABgBAAAAAQACAAEAABUBAgABAAABAQEAAAAAAAIAAAACAQECAAALAAABAAAAAAAAAQAAAAMBAAAAAAE=',
            'x-api-version': '3.0.91',
            'sec-ch-ua-mobile': '?0',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.93 Safari/537.36',
            'x-requested-with': 'fetch',
            'x-zse-96': encrypt_str,
            'x-app-za': 'OS=Web',
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="96", "Google Chrome";v="96"',
            'sec-ch-ua-platform': '"Windows"',
            'accept': '*/*',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-dest': 'empty',
            'referer': 'https://www.zhihu.com/search?type=content&q=%E6%B5%B7%E6%B4%8B',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cookie': '_zap=e672191e-00e2-4989-b790-7cae678ca137; _xsrf=20041567-d0cf-41d6-8dfc-3dcf7e38b723; d_c0="AHBQteodLhSPTn8r_unNZHj3uwaRCtW5AYQ=|1639472233"; __snaker__id=mqoUy0CyYU3Jkfvy; gdxidpyhxdE=mEmkYM8%5C3E0TufRjE%5C%2Bfus12zPQIU45VmPDT54fKdtAnQgXG6HEn9oRCQpRQlM%2BQWE%2BYEaPS85QkIIQN5cUytK3Kq4j96%2F18f5mSZII5EaBkRAx7c1S1PkPH%2ByYM2Govf%5CS%5CbBilIN%5CbHx7%5CiUrVDijkJArl%2B5%2F7rG4HAGn4Le6off%2Bb%3A1639473517368; _9755xjdesxxd_=32; YD00517437729195%3AWM_NI=opBWbLzd6T62zlsipbWyzcMpKF0R71oPPlaWwBehshPM8MWgF69nTfEsa08KRYq1Y%2BlDP%2BzqnJPs70TyMQWtuCXr5D4N0B0We0wkFNhY4GvTigXTo%2BYzrcTjUJnhJrZPQWE%3D; YD00517437729195%3AWM_NIKE=9ca17ae2e6ffcda170e2e6eea4e26a8aebe1a9aa6be9a88ab7c45b979b8eabf180b4f19aa9e166aba696ccc12af0fea7c3b92aadb08eb8e148babcfab5b53abab4bd8af36a95a7b684d07c899a00b3b63bad90a08de45db59eab89f2649493f8aed66d86eaf78fd76e87adafd1bb419287bfd2dc21b09ca0ccf97bae96a094b63c98a783b2d680b79d9893b850f89200a3b35da7f0b98cc546ac87fca8f560abb998b5ee219ba6be84d7629796a289c97a9a909fb8c837e2a3; YD00517437729195%3AWM_TID=sZ19tdhwJ%2FRFURFBUUJ64t6UHeniycvE; captcha_ticket_v2="2|1:0|10:1639472627|17:captcha_ticket_v2|704:eyJ2YWxpZGF0ZSI6IkNOMzFfT2lGbFp3LUk2QmlDUFl6aGlqVkl2S1h4NklQZGY0SC51TW40Zllocnc2azZUMlVLeG9IaWFVVDE3Zzc5R2plTTBFLkcyanNkLTFxWktldTFfcHdQMS1oaXB2V0ZqemdrT2k5OEFZc2pROGMtYmoyME5ldFN3b2JZMm1TQ3NyOWNqNDdNSXl3U0xhTS5Iak9aRDRqR1VaMFE0eWRROS5vYWphUWZrRFg0ZVB1VnQ5UFNtRk1Dc1VWMnRyZGpMQmhGMnRPdC5JSU5hQml6LmdRLUpjd3AyNTduVDF1T1l3dVlmSDJUay5sTC1DV0JSZ0gyZl9jMnVyRHhXenlXdG5oblZGZXU3X09scmI0WTJpd1AwSzlxc2t6NXZFLkw0eGRtRGkwR2E3QUN0YVZLREUteVowSy1xc3FOdHc4dDFqQXFna2cxQU5oRUdaamFUeWdKWHVIRDk3U1BXTi1WLlIwSXF3NE1mVi5nbkhNZmloLk5EOVktTHpNdXdnWk00RnlPVlJ3YXBEekgub2pBZ3RRS0tFaWMxN01lTTlwWW1rdVg2YWYyQlk0RlhoX1RteGhRSVNYWnFRanV3cFJuaVF2SmV1cjR2ZTl6TWJyYzJTamtLaC1oSUJrdTd2WWREdUhBRExHbW5zVnoyaF9samJCb0R0RnBjS1FHallqMyJ9|05624d791b1e45e2b53bbed64770795b55e4ccd0b75ae0f2130aa0ffaf307965"; z_c0="2|1:0|10:1639472639|4:z_c0|92:Mi4xY19LZEhnQUFBQUFBY0ZDMTZoMHVGQ1lBQUFCZ0FsVk5fNnVsWWdDRW4yM2U0R0pvSEhTU00xbWJTNmVMSkV4LXd3|5dd41844a5967b078e78c86fe436cfc11e9835e5da0a06320ed51e348b86ee59"; captcha_session_v2="2|1:0|10:1639472640|18:captcha_session_v2|88:emlQa2VlQXRpalZjNm4zMHRnWlNBVE43djM3Vmd3QTdlRitMYmlDeFpHQ0J5WDhBUDhCVnV6MmRBeVphdXVXSQ==|5e7d1286842edeb94c784de7e2d0a75a04c0f9144be538a2f763a4b3010731c5"; tst=r; SESSIONID=rsiSSVnO7Mzpqy6dt1Loms9CGPrUQRntasLJkxa8mlb; JOID=UFodB0vc38LbBsihDdpNVy0d0I0TrqanjFeexU7pkrKnc7OXYwDFdrwEwqcFPhQBOXeFUjL0cymc_bqp4rvwyYc=; osd=UlkdA0re3MLfB8qiDd5MVS4d1IwRraajjVWdxUrokLGnd7KVYADBd74HwqMEPBcBPXaHUTLwciuf_b6o4LjwzYY=; NOT_UNREGISTER_WAITING=1; Hm_lvt_98beee57fd2ef70ccdd5ca52b9740c49=1639535923,1639539154,1639718102,1639721911; KLBRSID=d017ffedd50a8c265f0e648afe355952|1639723981|1639718100; Hm_lpvt_98beee57fd2ef70ccdd5ca52b9740c49=1639723986',
        }
        return encrypt_str,request_url,headers


# 定义爬虫
def spider(key,nowpage=0,link=None):
    keyword = key
    key = parse.urlencode({'': key})
    if nowpage == 0:
        parse_url = f'/api/v4/search_v3?t=general&q{key}&correction=1&offset=0&limit=20&filter_fields=&lc_idx=0&show_all_topics=0&&search_source=Normal'
        encrypt_str, url, headers = get_encrypt(parse_url,keyword=key)
        response = requests.get(url=url, headers=headers,proxies=get_proxy())
        js = json.loads(response.text)
        # print(js['data'])
        for i in js['data']:
            try:
                consult_txt = i['highlight']['description'].replace('<em>', '').replace('</em>', '')
                consult_title = i['highlight']['title'].replace('<em>', '').replace('</em>', '')
                datasource = '知乎'
                consult_id = i['object']['author']['name']
                consult_link = 'https://www.zhihu.com/question/' + str(i['object']['question']['id'])
                timeStamp = i['object']['created_time']
                timeArray = time.localtime(timeStamp)
                consult_date = time.strftime("%Y-%m-%d", timeArray)
                a = re.findall(
                    '潮热|潮红|出汗|手脚冰冷|心悸|焦虑|易怒|烦躁|失眠|睡眠质量|生活质量|雌激素水平下降|激素替代疗法|激素治疗|非激素治疗|雌激素|孕激素|雄激素|中药|中成药|利维爱|替勃龙|雌二醇|补佳乐|诺坤复',
                    consult_title)
                b = re.findall(
                    '潮热|潮红|出汗|手脚冰冷|心悸|焦虑|易怒|烦躁|失眠|睡眠质量|生活质量|雌激素水平下降|激素替代疗法|激素治疗|非激素治疗|雌激素|孕激素|雄激素|中药|中成药|利维爱|替勃龙|雌二醇|补佳乐|诺坤复',
                    consult_txt)
                if a or b:
                    sql = """
                        insert into consultinfo(data_source,consult_id,consult_title,consult_date,consult_txt,consult_link) value(%s,%s,%s,%s,%s,%s)
                    """
                    cursor.execute(sql,
                                   (datasource, consult_id, consult_title, consult_date, consult_txt, consult_link))
                    print(datasource, consult_id, consult_txt, consult_title, consult_date, consult_link)
            except:
                pass
            # 提交事务
            conn.commit()
        nowpage += 1
        URL = js['paging']['next']
        print(URL)
        # 标记是否到底
        sign = js['paging']['is_end']
        if sign == False:
            spider(keyword, nowpage, URL)
    else:
        encrypt_str1, url1, headers1 = get_encrypt(link, nowpage,keyword=key)
        response1 = requests.get(url=url1, headers=headers1,proxies=get_proxy())
        js = json.loads(response1.text)
        # print(js['data'])
        for i in js['data']:
            try:
                consult_txt = i['highlight']['description'].replace('<em>', '').replace('</em>', '')
                consult_title = i['highlight']['title'].replace('<em>', '').replace('</em>', '')
                datasource = '知乎'
                consult_id = i['object']['author']['name']
                consult_link = 'https://www.zhihu.com/question/' + str(i['object']['question']['id'])
                timeStamp = i['object']['created_time']
                timeArray = time.localtime(timeStamp)
                consult_date = time.strftime("%Y-%m-%d", timeArray)
                a = re.findall('潮热|潮红|出汗|手脚冰冷|心悸|焦虑|易怒|烦躁|失眠|睡眠质量|生活质量|雌激素水平下降|激素替代疗法|激素治疗|非激素治疗|雌激素|孕激素|雄激素|中药|中成药|利维爱|替勃龙|雌二醇|补佳乐|诺坤复',consult_title)
                b = re.findall('潮热|潮红|出汗|手脚冰冷|心悸|焦虑|易怒|烦躁|失眠|睡眠质量|生活质量|雌激素水平下降|激素替代疗法|激素治疗|非激素治疗|雌激素|孕激素|雄激素|中药|中成药|利维爱|替勃龙|雌二醇|补佳乐|诺坤复',consult_txt)
                if a or b:
                    sql = """
                        insert into consultinfo(data_source,consult_id,consult_title,consult_date,consult_txt,consult_link) value(%s,%s,%s,%s,%s,%s)
                    """
                    cursor.execute(sql,
                                   (datasource, consult_id, consult_title, consult_date, consult_txt, consult_link))
                    print(datasource, consult_id, consult_txt, consult_title, consult_date, consult_link)
                # 提交事务
                conn.commit()
            except:
                pass
        nowpage += 1
        URL = js['paging']['next']
        print(URL)
        # 标记是否到底
        sign = js['paging']['is_end']
        if sign == False:
            spider(keyword, nowpage, URL)


if __name__ == '__main__':
    keyword = ['更年期失眠严重','更年期失眠','更年期怎么调理','绝经后如何保养','绝经后出血','绝经前症状','更年','绝经','绝经期','更年期','绝经过渡期','更年期血管舒缩症','绝经期血管舒缩症','更年期综合症','更年期症状','绝经期症状','绝经期激素治疗','绝经期如何补钙','更年期如何补钙','绝经期骨质疏松']
    for key in keyword:
        # key = '绝经期'
        spider(key)







