import requests,json,os
import execjs
import hashlib
import configparser
from urllib.request import quote

config = configparser.RawConfigParser()  # 实例化configParser对象
config.read('.\\keyword.ini', encoding='utf-8')
keyword = config.get('word', 'keyword')  #
x_zst_81 = f"{config.get('encryption', 'x_zst_81')}"  #
cookie_d_c0 = config.get('encryption', 'cookie_d_c0')  #
cookie = config.get('encryption', 'cookie')  #
page_count = config.getint('word', 'page_count')  #
for j in range(1,page_count,20):
    page_limit = j
    page_num = 20
    # utf8编码，指定安全字符
    encode_keyword = quote(keyword, safe=";/?:@&=+$,", encoding="utf-8")
    # print(encode_keyword)
    url = "/api/v4/search_v3?t=general&q="+ encode_keyword +f"&correction=1&offset={page_limit}&limit={page_num}&filter_fields=undefined&lc_idx={page_num}&show_all_topics=0&search_hash_id=dcfbf89a1c01497c5484d569120763e6&vertical_info=0%2C0%2C0%2C0%2C0%2C0%2C0%2C0%2C0%2C1"
    # x_zst_81 = "3_2.0ae3TnRUTEvOOUCNMTQnTSHUZo02p-HNMZBO8YD_02XtucXYqK6P0E79y-LS9-hp1DufI-we8gGHPgJO1xuPZ0GxCTJHR7820XM20cLRGDJXfgGCBxupMuD_Ie8FL7AtqM6O1VDQyQ6nxrRPCHukMoCXBEgOsiRP0XL2ZUBXmDDV9qhnyTXFMnXcTF_ntRueTh7N99hUOrMcOowHKM8288vcmwCCKCDxKlBe0SJ91kTF_XUNKmhg_abo1PcOPv_2_WUN1owxY1CxpJDCqmLFfSqgfeuFp6TLGKBxBIhUOwUO8b7LLnUeqnv3OqcOpUvXCGGYmr7VOiqVOZwYy8htMfvH_DBVsLGXLnwFLthLyku21fGV04qfzQRO8ObXMsGO0kuC0shr1FBHOeLNG19CLSbwGS7FMQge8DCN_pcLBJJOB9cOYlhc1LrofcUL_ggempDo1FuLZEBC1hUOL2ucqrQu9Zhw9IgH0uhLCWJrC"
    # cookie_d_c0 = "\"AADcrvhTRxGPTuT63H8IufBXUPD5a719Uuo=|1589624518\""
    str_to_md5 = "101_3_2.0"+ "+" + url + "+" + cookie_d_c0 + "+" + x_zst_81
    # print(str_to_md5)
    fmd5 = hashlib.md5(str_to_md5.encode(encoding='UTF-8')).hexdigest()
    with open('g_encrypt.js', 'r',encoding='utf-8') as f:
        ctx1 = execjs.compile(f.read())
    encrypt_str = ctx1.call('b', fmd5)
    # print(fmd5)
    # print(encrypt_str)

    headers = {
    # 'accept-encoding': 'gzip, deflate, br',
    'accept-encoding': 'gzip, deflate',
    'accept-language': 'zh-CN,zh;q=0.9',
    'cookie': cookie,
    'referer': f'https://www.zhihu.com/search?type=content&q={encode_keyword}',
    'sec-ch-ua': '"Chromium";v="92", " Not A;Brand";v="99", "Google Chrome";v="92"',
    'sec-ch-ua-mobile': '?0',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36',
    'x-ab-param': 'tp_dingyue_video=0;qap_question_visitor= 0;tp_topic_style=0;se_ffzx_jushen1=0;zr_slotpaidexp=1;tp_contents=2;pf_noti_entry_num=2;qap_question_author=0;pf_adjust=1;zr_expslotpaid=1;tp_zrec=1;top_test_4_liguangyi=1',
    'x-ab-pb': 'CqIBTwF9AgQEPwAIBAsEJQT0C+wKoANFBEMAwQL0A6sDNwybC+QK1wL4A7ULQAFtAokC6gMHDOAL9gIPC8oCCgQ0BGoBtArcC0cAUAOJDOgDNAxgC2kBjAK0AMICVgy5AsACoQMqAo4D1wvhAwkEzAIqA58CMgQ7AmwDhALYAlcD8wMOBDIDcgPHAqIDGwB0AY0BtwMHBFILpgFPAwELKgQzBM8LElEAAQAAAAABAAEAABUBAAABAAAAAAMBAAQLAQAAAQAAAAAAAAAAAAYAAAEAAAEBFQEAAAAAAAAAAQEAAQAAAAAAAgABAAAAAAAAAAEAAAEAAAs=',
    'x-api-version': '3.0.91',
    'x-app-za': 'OS=Web',
    'x-requested-with': 'fetch',
    'x-zse-93': '101_3_2.0',
    'x-zse-96': '2.0_' + encrypt_str,
    'x-zst-81': x_zst_81,
    }

    response = requests.get(url="https://www.zhihu.com" + url,headers=headers,verify=False)

    # print(response.headers)
    # response.encoding = response.apparent_encoding
    print(response.text)

    data = json.loads(response.text)
    if not os.path.exists(f".\\{keyword}"):
        os.mkdir(f".\\{keyword}")
    for i in data['data']:
        if i['type'] == 'search_result':
            try:
                print(i['index'], i['object']['content'])
                with open(f".\\{keyword}\\{i['index']}.{i['highlight']['title'].replace('<em>', '').replace('</em>', '').replace('？', '').replace('?', '')}.html", "w", encoding="utf-8") as f:
                    f.write(i['object']['content'])
            except:
                print('标签没数据')
                continue



