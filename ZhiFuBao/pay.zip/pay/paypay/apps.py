from django.apps import AppConfig


class PaypayConfig(AppConfig):
    name = 'paypay'
