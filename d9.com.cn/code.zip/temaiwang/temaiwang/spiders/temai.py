# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import Selector, HtmlXPathSelector
from scrapy.http import Request
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.join(BASE_DIR, "static")


class TemaiSpider(scrapy.Spider):
    name = 'temai'
    allowed_domains = ['temai.com']
    start_urls = ['https://d9.com.cn/category/More',]
    # start_urls = ['https://www.d9.com.cn/products/%E7%94%B5%E6%BA%90%E7%AE%A1%E7%90%86/PMIC%20-%20%E4%BB%A5%E5%A4%AA%E7%BD%91%E4%BE%9B%E7%94%B5%20(PoE)%20%E6%8E%A7%E5%88%B6%E5%99%A8/']
    """
    def parse1(self, response):
        classify_title="电源管理"
        a_text = "PMIC - 以太网供电 (POE) 控制器.txt"
        print(BASE_DIR)
        DIR = os.path.join(BASE_DIR,classify_title)
        ret = os.path.exists(DIR)
        file_path = os.path.join(DIR,a_text)
        if not ret:
            os.makedirs(DIR)
        search_results_tr = Selector(response=response).xpath("//div[@class='search_list']//tbody//tr")
        with open(file_path, "a+",encoding="utf-8") as f:
            for tr in search_results_tr:
                td_list = tr.xpath(".//td")
                for td in td_list:
                    content = td.xpath("string(.)").extract_first().strip()
                    print(content)
                    f.write(content)
                    f.write("-->")
                f.write("\n")

"""

    def parse(self, response):
        # content = response.body.decode(response.encoding)
        # 所有分类

        all_classify = Selector(response=response).xpath("//div[@class='classify-all']//dl[@class='clearfix']")
        for classify in all_classify:
            classify_title = classify.xpath(".//dt/text()").extract_first()
            dd_list = classify.xpath(".//dd")
            # print(classify_title)
            for dd in dd_list:
                a_text = dd.xpath(".//a/text()").extract_first()
                a_href = dd.xpath(".//a/@href").extract_first()
                # print("-" * 4, a_text)
                # print("-" * 4, a_href,type(a_href))
                yield Request(
                    url=a_href,
                    callback=self.handle_a,
                    dont_filter=True,
                    meta={
                        "classify_title": classify_title,
                        "a_text": a_text,
                    }
                )

    def handle_a(self, response):
        classify_title = response.meta["classify_title"]
        a_text = "%s.txt"%(response.meta["a_text"])
        # print(BASE_DIR)
        print(classify_title,"===>",a_text)
        # print(a_text)
        DIR = os.path.join(BASE_DIR, classify_title)
        ret = os.path.exists(DIR)
        file_path = os.path.join(DIR, a_text)
        if not ret:
            os.makedirs(DIR)
        search_results_tr = Selector(response=response).xpath("//div[@class='search_list']//tbody//tr")
        with open(file_path, "a+", encoding="utf-8") as f:
            for tr in search_results_tr:
                td_list = tr.xpath(".//td")
                for td in td_list:
                    content = td.xpath("string(.)").extract_first().strip()
                    # print(content)
                    f.write(content)
                    f.write("-->")
                f.write("\n")
