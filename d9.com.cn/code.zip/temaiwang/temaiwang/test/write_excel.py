'''
设置单元格样式
'''
import xlwt
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
ECCC_DIR = os.path.join(BASE_DIR, "ecccc")


def set_style(name, height, bold=False):
    style = xlwt.XFStyle()  # 初始化样式

    font = xlwt.Font()  # 为样式创建字体
    font.name = name  # 'Times New Roman'
    font.bold = bold
    font.color_index = 4
    font.height = height

    # borders= xlwt.Borders()
    # borders.left= 6
    # borders.right= 6
    # borders.top= 6
    # borders.bottom= 6

    style.font = font
    # style.borders = borders

    return style


# 写excel
def write_excel(file_path, p, ex_dir):
    p = p + ".xlsx"
    ex = xlwt.Workbook()  # 创建工作簿

    '''
    创建第一个sheet:
        sheet1
    '''
    sheet1 = ex.add_sheet(u'sheet1', cell_overwrite_ok=True)  # 创建sheet
    row0 = ["制造商型号", "制造商", "描述", "库存数量", "批号", "起订量", "单价含税(13%)", "香港交货价", "货期"]
    # column0 = [u'机票',u'船票',u'火车票',u'汽车票',u'其它']
    # status = [u'预订',u'出票',u'退票',u'业务小计']

    # 生成表头
    for i in range(len(row0)):
        sheet1.write(0, i, row0[i], set_style('Times New Roman', 220, True))
    # 生成数据
    with open(file_path, "r", encoding="utf-8") as f:
        count = 1
        for line in f:
            # print(line.split("-->"))
            *data_list, caozuo, nn = line.split("-->")
            for col in range(len(data_list)):
                sheet1.write(count, col, data_list[col])
            count += 1
    save_path = os.path.join(ex_dir, p)
    ex.save(save_path)  # 保存文件


def main():
    static_list = os.listdir(STATIC_DIR)
    # print(static_list)
    for path in static_list:
        st_dir = os.path.join(STATIC_DIR, path)
        ex_dir = os.path.join(ECCC_DIR, path)
        ret = os.path.exists(ex_dir)
        if not ret:
            os.makedirs(ex_dir)
        st_dir_list = os.listdir(st_dir)
        for p in st_dir_list:
            file_path = os.path.join(st_dir, p)

            p = p.rsplit(".", maxsplit=1)[0]
            # print(p, ex_dir)
            write_excel(file_path, p, ex_dir)


if __name__ == '__main__':
    # generate_workbook()
    # read_excel()
    # write_excel()
    # print(STATIC_DIR)
    # print(ECCC_DIR)
    # print(os.listdir(os.path.join(STATIC_DIR,os.listdir(STATIC_DIR)[0])))
    main()
