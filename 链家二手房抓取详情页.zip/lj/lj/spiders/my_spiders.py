#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by iFantastic on 2022/6/7
import re 
import scrapy
from scrapy.cmdline import execute



class LJ_spiders(scrapy.Spider):
    name = 'lj'
    start_urls = ['https://cs.lianjia.com/ershoufang/pg1/']

    def parse(self, response, **kwargs):
        for info in  response.xpath('//div[@data-role="ershoufang"]/div[1]/a/@href'):
            yield response.follow(url=info.get(),callback=self.parse_info)
    
    def parse_info(self, response):
        for info in  response.xpath('//div[@data-role="ershoufang"]/div[2]/a/@href'):
            yield response.follow(url=info.get(),callback=self.parse_page)

    def parse_page(self,response):
        url = response.url+'pg{}/'
        pages = re.findall(r'"totalPage":(.*?),', response.text)[0]
        for page in range(1, int(pages)+1):
            yield scrapy.Request(url=url.format(page),callback=self.parse_item)
    
    def parse_item(self, response):
        for info in response.xpath("//div[@class='info clear']"):
            yield {
                'title': info.xpath('./div[@class="title"]/a/text()').get(),
                'positionInfo': info.xpath('./div[@class="flood"]//a//text()').get(),
                'houseInfo': info.xpath('./div[@class="address"]/div/text()').get(),
                'totalPrice': info.xpath('//div[@class="priceInfo"]/div[1]/span/text()').get() + '万',
                'unitPrice': info.xpath('//div[@class="priceInfo"]/div[2]/span/text()').get()
            }


if __name__ == '__main__':
    execute('scrapy crawl lj -o 长沙二手房.csv'.split())
    # execute('scrapy crawl lj'.split())
